import { useState } from 'react';
import { auth } from '../firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';

function Signup() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const signupUser = async () => {
    try {
      await createUserWithEmailAndPassword(auth, email, password);
      navigate('/dashboard');
    } catch (err) {
      alert(err.message);
    }
  };

  return (
    <div className="p-4 max-w-md mx-auto mt-20 shadow-xl rounded-xl">
      <h1 className="text-xl font-bold mb-4">A.Q Khan - Sign Up</h1>
      <input type="email" className="input" placeholder="Email" onChange={(e) => setEmail(e.target.value)} />
      <input type="password" className="input mt-2" placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
      <button className="btn mt-4" onClick={signupUser}>Sign Up</button>
    </div>
  );
}

export default Signup;