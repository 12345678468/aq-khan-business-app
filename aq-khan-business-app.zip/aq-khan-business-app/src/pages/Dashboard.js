function Dashboard() {
  return <h1 className="text-2xl p-6">Welcome to A.Q Khan Business App!</h1>;
}

export default Dashboard;